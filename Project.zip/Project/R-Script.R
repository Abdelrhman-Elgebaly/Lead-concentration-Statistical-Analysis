lead_df<-get(load("E:/NU/Spring-22/BMD407/Project/lead.RData"))

lead_df$Sex<-factor(lead_df$Sex,labels=c('Male','Female'))
library(infer)
library(tibble)
##Male
male_sample <- tibble(
  male = c(lead_df[lead_df$Sex == "Male",]$MAXFWT)
)

##
bootstrap_distribution <- male_sample %>% 
  specify(response = male) %>% 
  generate(reps = 1000, type = "bootstrap") %>% 
  calculate(stat = "mean")
visualize(bootstrap_distribution)

percentile_ci <- bootstrap_distribution %>% 
  get_confidence_interval(level = 0.95, type = "percentile")
percentile_ci

visualize(bootstrap_distribution) + 
  shade_confidence_interval(endpoints = percentile_ci)


###Female
female_sample <- tibble(
  female = c(lead_df[lead_df$Sex == "Female",]$MAXFWT)
)

##
bootstrap_distribution <- female_sample %>% 
  specify(response = female) %>% 
  generate(reps = 1000, type = "bootstrap") %>% 
  calculate(stat = "mean")
visualize(bootstrap_distribution)

percentile_ci <- bootstrap_distribution %>% 
  get_confidence_interval(level = 0.95, type = "percentile")
percentile_ci

visualize(bootstrap_distribution) + 
  shade_confidence_interval(endpoints = percentile_ci)



