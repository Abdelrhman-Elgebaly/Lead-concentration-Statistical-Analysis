
lead_df<-get(load("E:/NU/Spring-22/BMD407/Project/lead.RData"))
library(infer)
#Step 1: Calculate the mean
meanData=tapply(lead_df$MAXFWT,list(lead_df$Sex),mean,na.rm=T)
firstGender=meanData[1][1]
secondGender=meanData[2][1]
#Step 2: Calculate the standard error of the mean
sample.n <- length(lead_df$MAXFWT)
sample.sd <- sd(lead_df$MAXFWT,na.rm=T)
sample.se <- sample.sd/sqrt(sample.n)
print(sample.se)
#Step 3: Find the t-score that corresponds to the confidence level
# 95% C.I alpha = 0.05
# 90% C.I alpha = 0.1
# 99 C.I alpha = 0.01

alpha = 0.05
degrees.freedom = sample.n - 1
t.score = qt(p=alpha/2, df=degrees.freedom,lower.tail=F)
print(t.score)

#Step 4. Calculate the margin of error and construct the confidence interval
# For Gender 1
margin.error <- t.score * sample.se
lower.bound <- firstGender - margin.error
upper.bound <- firstGender + margin.error
print(c(lower.bound,upper.bound))

# For Gender 2
margin.error <- t.score * sample.se
lower.bound <- secondGender - margin.error
upper.bound <- secondGender + margin.error
print(c(lower.bound,upper.bound))